# Connecter ton agent Hermes à FlowFlow

Kit de transmission préparé le 9 septembre 2026.
Skill FlowFlow 1.2.0, contrat MCP 3. Ce kit ne contient aucun secret.
Il ne contient pas Hermes lui-même et ne requiert pas de cloner FlowFlow.

## 1. Ce que tu fais dans FlowFlow

Ton compte web doit être lié à l’app et Premium doit être actif.
Dans l’app iPhone ou Mac :

1. Crée ou choisis un espace dont tu es propriétaire.
2. Prépare dans cet espace un dossier collaboratif si Hermes doit écrire.
3. Menu à trois points de l’espace → Accès Hermes.
4. Choisis Lecture seule ou Lecture et écriture, puis Créer l’accès.
5. Copie immédiatement le jeton affiché une seule fois, commençant par `mcps_`.

Ce jeton est limité à cet espace. Ce n’est ni ton code de liaison d’appareil,
ni un jeton administrateur. Un dossier local non partagé n’est pas visible.
Ne recrée pas un agent si tu disposes déjà du bon accès : régénère son jeton.

Ne colle PAS le jeton sur Discord, dans une conversation Hermes, une note,
un fichier du kit ou une commande shell. Il doit être saisi dans un éditeur
privé sur la machine qui exécute Hermes.

## 2. Transmettre ce dossier à Hermes

Décompresse le ZIP sur la machine qui exécute réellement ton agent Hermes.
Si Hermes est sur un VPS, installer le kit sur ton ordinateur seul ne suffit pas.
Les instructions ci-dessous ciblent Linux et macOS ; sous Windows, utilise
l’environnement Linux/WSL dans lequel Hermes est installé.

Donne à Hermes le fichier `POUR-HERMES.md`. Il peut préparer l’installation
et t’indiquer où saisir le jeton sans te demander de l’envoyer dans le chat.

## 3. Installation du skill

Depuis la racine du dossier décompressé :

```sh
sh scripts/install-flowflow-hermes-skill.sh
```

Le script copie le skill et ses quatre références dans
`~/.hermes/skills/productivity/flowflow-spaces/`.
Il sauvegarde une ancienne copie hors du répertoire de découverte des skills.
Si Hermes utilise un répertoire personnalisé, définir HERMES_HOME pour ce
script et utiliser ce même répertoire pour la configuration et le fichier .env.

Le script installe uniquement le skill, pas la connexion MCP.

## 4. Configurer la connexion

Sauvegarde la configuration existante. Dans `~/.hermes/config.yaml`, fusionne
l’entrée suivante sous l’éventuel `mcp_servers` existant. Ne remplace pas les
autres serveurs et ne crée pas deux clés `mcp_servers`.

```yaml
mcp_servers:
  flowflow_mon_espace:
    url: "https://api.flowflow.be/v1/mcp-spaces"
    headers:
      Authorization: "Bearer ${FLOWFLOW_TOKEN_MON_ESPACE}"
    timeout: 30
```

Dans un éditeur privé, ajoute dans `~/.hermes/.env` une ligne
`FLOWFLOW_TOKEN_MON_ESPACE=` suivie de ton vrai jeton, sans l’afficher ici.
Préserve les autres variables. Protège ce fichier :

```sh
chmod 600 ~/.hermes/.env
```

Recharge ou redémarre l’instance Hermes concernée pour qu’elle relise la
configuration, l’environnement et le skill. La procédure dépend de son
installation : ne lance pas une deuxième instance pour contourner cela.

## 5. Première vérification, sans écriture

Envoie à Hermes :

> Utilise le skill flowflow-spaces et le serveur flowflow_mon_espace.
> Vérifie space_info, puis pull_changes et list_folders. Donne-moi le nom
> de l’espace, le contrat, les permissions, l’expiration et les dossiers
> accessibles. Ne crée, ne modifie et ne supprime aucune note.

Le nom doit correspondre au bon espace. Le contrat attendu est 3.
Un espace vide est valide. Une connexion réussie ne prouve pas encore qu’une
écriture est autorisée : il faut read_write ET un dossier writable=true.
Les appels pull_changes sont espacés d’au moins 30 secondes.

Le Premium et le jeton ont des expirations distinctes. Vérifie expires_at
renvoyé par space_info et régénère le jeton avant son expiration.

## Ensuite

Commence par lui demander de lire une note précise. Autorise séparément toute
création. Hermes ne doit pas modifier tes notes humaines ni créer une routine
ou un cron sans ton accord. Le guide complet est dans
`docs/guides/hermes-flowflow.md` et les workflows dans le skill.

Si le serveur est absent : vérifier config puis recharger Hermes.
Si HTTP 404/unauthorized : jeton invalide, expiré ou révoqué.
Si space_read_only : vérifier le Premium du propriétaire.
Si writable=false : vérifier le mode collaboratif et le dossier choisi.

## Contenu et provenance

- Guide original de FlowFlow, adapté uniquement pour l’installation depuis ce
  ZIP et pour préciser Premium/création d’accès et la note racine d’un thread.
- Skill publié et ses quatre références, inchangés.
- Script d’installation existant, inchangé.
- Instructions de transmission en français et empreintes SHA-256.

Aucun accès administrateur et aucun jeton personnel ne doivent être ajoutés
au ZIP avant son envoi. La connexion sur ta machine reste à vérifier avec ton
propre jeton ; elle n’a pas été exécutée lors de la préparation du kit.
